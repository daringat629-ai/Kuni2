#!/usr/bin/env python3
"""Напоминания Марин. add "18:30" "текст" | add "2026-10-05 18:30" "текст" | list | due | done ID"""
import json, os, sys, time, datetime

DIR = os.path.dirname(os.path.abspath(__file__))
FILE = os.path.join(DIR, "reminders.json")


def load():
    return json.load(open(FILE, encoding="utf-8")) if os.path.exists(FILE) else []


def save(items):
    json.dump(items, open(FILE, "w", encoding="utf-8"), ensure_ascii=False, indent=1)


def parse(when):
    now = datetime.datetime.now()
    for fmt in ("%Y-%m-%d %H:%M", "%H:%M"):
        try:
            t = datetime.datetime.strptime(when, fmt)
            if fmt == "%H:%M":
                t = now.replace(hour=t.hour, minute=t.minute, second=0, microsecond=0)
                if t <= now:
                    t += datetime.timedelta(days=1)
            return t
        except ValueError:
            pass
    raise SystemExit("Неверное время. Формат: HH:MM или YYYY-MM-DD HH:MM")


def main():
    a = sys.argv[1:]
    cmd = a[0] if a else "list"
    items = load()
    if cmd == "add":
        if len(a) < 3:
            raise SystemExit('Использование: remind.py add "18:30" "текст"')
        t = parse(a[1])
        nid = max([i["id"] for i in items] + [0]) + 1
        items.append({"id": nid, "at": t.strftime("%Y-%m-%d %H:%M"), "text": " ".join(a[2:]), "notified": False, "done": False})
        save(items)
        print(f"Напоминание #{nid} на {t:%Y-%m-%d %H:%M}.")
    elif cmd == "list":
        act = [i for i in items if not i["done"]]
        print("\n".join(f"#{i['id']} {i['at']} {'(уже напомнила)' if i['notified'] else ''} {i['text']}" for i in act) or "Напоминаний нет.")
    elif cmd == "due":
        nowstr = time.strftime("%Y-%m-%d %H:%M")
        due = [i for i in items if not i["done"] and not i["notified"] and i["at"] <= nowstr]
        for i in due:
            i["notified"] = True
        save(items)
        print("\n".join(f"Пора напомнить (#{i['id']}, было на {i['at']}): {i['text']}" for i in due) or "Просроченных напоминаний нет.")
    elif cmd == "done":
        for i in items:
            if str(i["id"]) == (a[1] if len(a) > 1 else ""):
                i["done"] = True
        save(items)
        print("Готово.")
    else:
        print("Команды: add, list, due, done")


main()
