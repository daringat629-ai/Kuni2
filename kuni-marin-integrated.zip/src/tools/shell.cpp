#include "shell.h"

#include <cstdio>
#include <cstdlib>
#include <string>

static constexpr auto LOG_TAG = "tools::shell";

static std::string shQuote(const std::string& s) {
    std::string r = "'";
    for (char c : s) {
        if (c == '\'') {
            r += "'\\''";
        } else {
            r += c;
        }
    }
    return r + "'";
}

OpenAITools::Tool tools::shell() {
    return {
        .name = "shell",
        .description = "Runs a bash command on your Ubuntu laptop (60s timeout, output truncated to 8000 bytes). "
                       "Each call is a separate process, so cd does not persist.",
        .parameters = {
            .properties = {
                {"command", {.type = "string", .description = "bash command to execute"}},
            },
            .required = {"command"},
        },
        .handler = [](OpenAITools::Ctx ctx) -> AFuture<AString> {
            auto cmd = ctx.args["command"].asStringOpt().valueOrException("command string is required");
            ALogger::warn(LOG_TAG) << "EXEC: " << cmd;
            // If KUNI_SHELL_CONTAINER is set, commands run inside that docker container (sandbox), not on the host.
            std::string runner = "bash -c ";
            if (const char* container = std::getenv("KUNI_SHELL_CONTAINER"); container != nullptr && *container) {
                runner = "docker exec -i " + shQuote(container) + " bash -c ";
            }
            std::string full = "timeout 60 " + runner + shQuote(cmd.toStdString()) + " </dev/null 2>&1 | head -c 8000";
            std::string out;
            if (FILE* p = popen(full.c_str(), "r")) {
                char buf[512];
                while (size_t n = fread(buf, 1, sizeof buf, p)) {
                    out.append(buf, n);
                }
                pclose(p);
            }
            if (out.empty()) {
                co_return AString("(no output)");
            }
            co_return AString::fromUtf8(AStringView(out.data(), out.size()));
        },
    };
}
