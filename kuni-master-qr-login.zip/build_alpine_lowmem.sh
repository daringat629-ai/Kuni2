\
#!/bin/sh
set -eu
cd "$(dirname "$0")"

BUILD_DIR="${BUILD_DIR:-build-alpine}"
BUILD_JOBS="${BUILD_JOBS:-1}"

echo "[Marin/Kuni] Alpine low-memory build"
echo "Build directory: ${BUILD_DIR}"
echo "Parallel jobs: ${BUILD_JOBS}"
echo "Using Release + -O1 -g0 to reduce compiler memory and disk use."

cmake -S . -B "$BUILD_DIR" -G Ninja \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_CXX_FLAGS_RELEASE="-O1 -DNDEBUG -g0" \
  -DKUNI_BUILD_TESTS=OFF \
  -DKUNI_USE_FFMPEG=OFF

cmake --build "$BUILD_DIR" --target kuni --parallel "$BUILD_JOBS"
echo "[OK] Binary: ${BUILD_DIR}/bin/kuni"
